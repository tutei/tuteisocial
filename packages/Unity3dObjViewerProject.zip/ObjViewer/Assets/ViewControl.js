var target : Transform;
var distance = 10.0;
 
var xSpeed = 15.0;
var ySpeed = 175.0;
 
var yMinLimit = -20;
var yMaxLimit = 200;
 
var distanceMin = 3;
var distanceMax = 250;
 
private var x = 0.0;
private var y = 0.0;

private var ydist=0.0;
private var xdist=0.0;
 
 
@script AddComponentMenu("Camera-Control/Mouse Orbit")
 
function Start () {
    var angles = transform.eulerAngles;
    x = angles.y;
    y = angles.x;
    
    
    //ObjImporter o = new ObjImporter();
    
    //o.ImportFile("http://people.sc.fsu.edu/~burkardt/data/obj/cessna.obj");
   
    // Make the rigid body not change rotation
    if (rigidbody)
        rigidbody.freezeRotation = true;
}
 
function LateUpdate () {

	if(GameObject.Find("obj_gameobject")!=null) target=GameObject.Find("obj_gameobject").transform;

    if (target) {
        if(Input.GetMouseButton(0)) x += Input.GetAxis("Mouse X") * xSpeed * distance* 0.02;
        if(Input.GetMouseButton(0)) y -= Input.GetAxis("Mouse Y") * ySpeed * 0.02;
 
       y = ClampAngle(y, yMinLimit, yMaxLimit);
       ydist+=Input.GetAxisRaw("Vertical") * Time.deltaTime*2;
	   xdist+=Input.GetAxisRaw("Horizontal") * Time.deltaTime*2;
        var rotation = Quaternion.Euler(y, x, 0);
 
        //distance = Mathf.Clamp(distance - Input.GetAxis("Mouse ScrollWheel")*5, distanceMin, distanceMax);
       
        var hit : RaycastHit;
        if (Physics.Linecast (target.position, transform.position, hit)) {
                distance -=  hit.distance;
        }
       
        var position = rotation * Vector3(xdist, ydist, -distance) + target.position;
 
        transform.rotation = rotation;
        transform.position = position;
   
    }

}
 
 
static function ClampAngle (angle : float, min : float, max : float) {
    if (angle < -360)
        angle += 360;
    if (angle > 360)
        angle -= 360;
    return Mathf.Clamp (angle, min, max);
}

function OnGUI() {
	if (GUI.Button(Rect(10,10,30,30),"+"))
	distance = Mathf.Clamp(distance - 1, distanceMin, distanceMax);
	if (GUI.Button(Rect(10,50,30,30),"-"))
	distance = Mathf.Clamp(distance + 1, distanceMin, distanceMax);
}
 